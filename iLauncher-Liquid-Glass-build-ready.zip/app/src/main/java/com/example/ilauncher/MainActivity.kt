package com.example.ilauncher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val White = Color(0xFFF8F8FC)
private val Soft = Color(0xFFC7CAD5)
private val Blue = Color(0xFF9DB8FF)
private val GlassFill = Color(0x38FFFFFF)
private val GlassLine = Color(0x66FFFFFF)

data class AppInfo(
    val label: String,
    val pkg: String,
    val icon: androidx.compose.ui.graphics.ImageBitmap,
    val isSystem: Boolean
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        setContent { LiquidLauncher() }
    }
}

@Composable
private fun LiquidLauncher() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var allApps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var page by remember { mutableIntStateOf(0) } // 0 home, 1 library
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<AppInfo?>(null) }
    var homeSet by remember { mutableStateOf<Set<String>>(emptySet()) }
    var pageIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        allApps = withContext(Dispatchers.IO) { loadApps(context) }
        val prefs = context.getSharedPreferences("liquid_launcher", Context.MODE_PRIVATE)
        homeSet = prefs.getStringSet("home_apps", null)?.toSet()
            ?: allApps.take(20).map { it.pkg }.toSet()
        loading = false
    }
    fun persist(next: Set<String>) {
        homeSet = next
        context.getSharedPreferences("liquid_launcher", Context.MODE_PRIVATE)
            .edit().putStringSet("home_apps", next).apply()
    }

    val homeApps = allApps.filter { it.pkg in homeSet }
    val pageSize = 20
    val pages = (homeApps.size + pageSize - 1) / pageSize
    val currentApps = homeApps.drop(pageIndex * pageSize).take(pageSize)
    val filtered = allApps.filter { it.label.contains(query, true) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Color(0xFF101522),
        surface = Color(0xFF242B3A),
        primary = Blue,
        onBackground = White,
        onSurface = White
    )) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.linearGradient(
                    listOf(Color(0xFF536A91), Color(0xFF252E46), Color(0xFF111521), Color(0xFF080A10))
                )
            )
        ) {
            // Decorative soft light blooms behind the glass surfaces.
            Box(Modifier.align(Alignment.TopEnd).offset(x = 75.dp, y = 125.dp)
                .size(230.dp).clip(CircleShape).background(Color(0x335E8BFF)))
            Box(Modifier.align(Alignment.BottomStart).offset(x = (-90).dp, y = (-100).dp)
                .size(260.dp).clip(CircleShape).background(Color(0x224DC6D8)))

            AnimatedContent(
                targetState = page,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally(tween(330)) { it / 5 } + fadeIn(tween(220))) togetherWith
                            (slideOutHorizontally(tween(260)) { -it / 8 } + fadeOut(tween(180)))
                    } else {
                        (slideInHorizontally(tween(330)) { -it / 8 } + fadeIn(tween(220))) togetherWith
                            (slideOutHorizontally(tween(260)) { it / 5 } + fadeOut(tween(180)))
                    }
                },
                label = "screenTransition"
            ) { screen ->
                if (screen == 0) {
                    HomeScreen(
                        apps = currentApps,
                        loading = loading,
                        editing = editing,
                        pageIndex = pageIndex,
                        pageCount = maxOf(1, pages),
                        onLaunch = { launchApp(context, it) },
                        onLongPress = { selected = it },
                        onSearch = { page = 1 },
                        onEdit = { editing = !editing },
                        onRemove = { persist(homeSet - it.pkg) },
                        onPage = { delta ->
                            pageIndex = (pageIndex + delta).coerceIn(0, maxOf(0, pages - 1))
                        }
                    )
                } else {
                    LibraryScreen(
                        apps = filtered,
                        query = query,
                        onQuery = { query = it },
                        onBack = { page = 0; query = "" },
                        onLaunch = { launchApp(context, it) },
                        onLongPress = { selected = it }
                    )
                }
            }

            selected?.let { app ->
                AppMenu(
                    app = app,
                    onClose = { selected = null },
                    onInfo = {
                        selected = null
                        context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${app.pkg}")))
                    },
                    onUninstall = {
                        selected = null
                        context.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
                    },
                    onRemove = { persist(homeSet - app.pkg); selected = null }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    apps: List<AppInfo>,
    loading: Boolean,
    editing: Boolean,
    pageIndex: Int,
    pageCount: Int,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onSearch: () -> Unit,
    onEdit: () -> Unit,
    onRemove: (AppInfo) -> Unit,
    onPage: (Int) -> Unit
) {
    val date = remember { SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()) }
    var dragAmount by remember { mutableFloatStateOf(0f) }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 20.dp)
            .pointerInput(pageIndex, pageCount) {
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, amount -> dragAmount += amount },
                    onDragEnd = {
                        if (dragAmount < -65) onPage(1)
                        if (dragAmount > 65) onPage(-1)
                        dragAmount = 0f
                    }
                )
            }
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("9:41", color = White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(date, color = Soft, fontSize = 12.sp)
            }
            Text("●  ▮▮▮  ▰", color = White, fontSize = 13.sp)
        }

        Spacer(Modifier.height(28.dp))
        Text("Good evening", color = White, fontSize = 32.sp, fontWeight = FontWeight.Light)
        Text("A little space for your day.", color = Soft, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassWidget("WEATHER", "☀", "Clear skies", Modifier.weight(1f))
            GlassWidget("BATTERY", "ϟ", "Your device", Modifier.weight(1f))
        }
        Spacer(Modifier.height(22.dp))

        if (loading) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Blue)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(top = 3.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                items(apps, key = { it.pkg }) { app ->
                    GlassAppIcon(
                        app = app,
                        editing = editing,
                        onClick = { if (editing) onRemove(app) else onLaunch(app) },
                        onLongPress = { onLongPress(app) }
                    )
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(bottom = 9.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            repeat(pageCount) { index ->
                val selected = index == pageIndex
                Box(Modifier.padding(horizontal = 3.dp).size(if (selected) 7.dp else 5.dp)
                    .clip(CircleShape).background(if (selected) White else Color(0x77FFFFFF)))
            }
        }

        if (editing) {
            GlassPanel(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = onEdit) { Text("Cancel", color = White) }
                    Text("Tap an app to remove", color = Soft, fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.CenterVertically))
                    TextButton(onClick = onEdit) { Text("Done", color = Blue) }
                }
            }
        } else {
            GlassPanel(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Dock shows up to four frequently visible shortcuts from this home page.
                    apps.take(4).forEach { app ->
                        GlassAppIcon(app, false, { onLaunch(app) }, { onLongPress(app) }, dock = true)
                    }
                    DockSearch(onClick = onSearch)
                }
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 2.dp), horizontalArrangement = Arrangement.Center) {
                TextButton(onClick = onEdit) { Text("Edit Home Screen", color = Soft, fontSize = 12.sp) }
                TextButton(onClick = onSearch) { Text("App Library  ⌕", color = Soft, fontSize = 12.sp) }
            }
        }
    }
}

@Composable
private fun GlassWidget(title: String, symbol: String, detail: String, modifier: Modifier = Modifier) {
    GlassPanel(modifier) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Soft, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(8.dp))
            Text(symbol, color = White, fontSize = 25.sp)
            Text(detail, color = White, fontSize = 13.sp)
        }
    }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(27.dp))
            .background(Brush.linearGradient(listOf(Color(0x55FFFFFF), Color(0x1AFFFFFF), Color(0x22A8C4FF))))
            .border(1.dp, GlassLine, RoundedCornerShape(27.dp))
    ) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(
            Brush.horizontalGradient(listOf(Color.Transparent, Color(0xAAFFFFFF), Color.Transparent))))
        content()
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GlassAppIcon(
    app: AppInfo,
    editing: Boolean,
    onClick: () -> Unit,
    onLongPress: () -> Unit,
    dock: Boolean = false
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.88f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "iconPress"
    )
    Column(
        Modifier.fillMaxWidth().scale(scale)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongPress,
                onLongClickLabel = "App options"
            )
            .padding(3.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box {
            androidx.compose.foundation.Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier.size(if (dock) 43.dp else 53.dp)
                    .clip(RoundedCornerShape(if (dock) 13.dp else 16.dp))
            )
            if (editing) {
                Box(Modifier.align(Alignment.TopEnd).offset(x = 4.dp, y = (-4).dp)
                    .size(17.dp).clip(CircleShape).background(Color(0xFFE95E70)),
                    contentAlignment = Alignment.Center) {
                    Text("−", color = White, fontSize = 13.sp, lineHeight = 13.sp)
                }
            }
        }
        if (!dock) {
            Spacer(Modifier.height(5.dp))
            Text(app.label, color = White, fontSize = 10.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun DockSearch(onClick: () -> Unit) {
    Box(
        Modifier.size(43.dp).clip(RoundedCornerShape(15.dp))
            .background(Color(0x33FFFFFF))
            .border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(15.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text("⌕", color = White, fontSize = 27.sp)
    }
}

@Composable
private fun LibraryScreen(
    apps: List<AppInfo>,
    query: String,
    onQuery: (String) -> Unit,
    onBack: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit
) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Home", color = White) }
            Spacer(Modifier.weight(1f))
            Text("App Library", color = White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.width(8.dp))
        }
        GlassPanel(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("⌕", color = Soft, fontSize = 22.sp)
                Spacer(Modifier.width(10.dp))
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 15.sp),
                    decorationBox = { inner ->
                        if (query.isEmpty()) Text("Search apps", color = Soft, fontSize = 15.sp)
                        inner()
                    }
                )
            }
        }
        Spacer(Modifier.height(18.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
            contentPadding = PaddingValues(bottom = 25.dp)
        ) {
            items(apps, key = { it.pkg }) { app ->
                GlassAppIcon(app, false, { onLaunch(app) }, { onLongPress(app) })
            }
        }
    }
}

@Composable
private fun AppMenu(
    app: AppInfo,
    onClose: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
    onRemove: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(app.label, color = White) },
        text = { Text("App actions", color = Soft) },
        confirmButton = { TextButton(onClick = onInfo) { Text("App info", color = Blue) } },
        dismissButton = {
            Row {
                TextButton(onClick = onRemove) { Text("Remove from Home", color = White) }
                if (!app.isSystem) TextButton(onClick = onUninstall) { Text("Uninstall", color = White) }
            }
        },
        containerColor = Color(0xFF252D3D)
    )
}

private fun loadApps(context: Context): List<AppInfo> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != context.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            val info = ri.activityInfo.applicationInfo
            AppInfo(
                label = ri.loadLabel(pm).toString(),
                pkg = ri.activityInfo.packageName,
                icon = ri.loadIcon(pm).toBitmap(192).asImageBitmap(),
                isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            )
        }
        .sortedBy { it.label.lowercase() }
}

private fun Drawable.toBitmap(size: Int): Bitmap {
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    setBounds(0, 0, size, size)
    draw(canvas)
    return bitmap
}

private fun launchApp(context: Context, app: AppInfo) {
    context.packageManager.getLaunchIntentForPackage(app.pkg)?.let {
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(it)
    }
}
