# iLauncher Liquid Glass

Android phone launcher project (portrait layout). It is designed to be installed as a normal Android HOME app; root is not required.

## Build an APK with GitHub Actions

1. Create a new repository on GitHub.
2. Upload the **contents** of this folder to the repository (the `.github/workflows/build.yml` file must be included).
3. Open the repository's **Actions** tab.
4. Select **Build APK** and run **Run workflow** (or push a commit).
5. Open the completed workflow run, download the `iLauncher-Liquid-Glass-debug` artifact, and extract it.
6. Install `app-debug.apk` on your Android phone. If Android asks, allow installation from the app you used to open the APK.
7. Press Home and select **iLauncher Liquid Glass** as the default launcher.

## Notes

- This is a debug APK workflow, not a Play Store release.
- The project has not been compiled or device-tested in this environment.
- Weather and battery tiles are visual placeholders in this build.
- Some blur effects are simulated with translucent gradients, so the exact appearance depends on Android version and device rendering.
